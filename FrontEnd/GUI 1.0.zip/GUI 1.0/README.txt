Install the access database engine from here - https://www.microsoft.com/en-us/download/details.aspx?id=54920
When opening the GUI select "test_db.accdb".